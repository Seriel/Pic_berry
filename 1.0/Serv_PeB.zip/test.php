<?php
    phpinfo();
?>
