<?php
   $dbname = 'pic_berry';
   $username = 'root';
   $password = 'MySqlPassword';
   $password = '';
?>
